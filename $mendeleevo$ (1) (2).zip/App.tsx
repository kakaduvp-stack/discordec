import React, { useState, useEffect } from 'react';
import { Server, Channel, User, Message } from './types';
import ServerSidebar from './components/ServerSidebar';
import ChannelSidebar from './components/ChannelSidebar';
import ChatArea from './components/ChatArea';
import UserSidebar from './components/UserSidebar';
import AuthScreen from './components/AuthScreen';

// Initial Data
const INITIAL_SERVER_DATA: Server[] = [
  {
    id: 's1',
    name: '$mendeleevo$',
    icon: 'https://picsum.photos/100',
    members: [], // Will be populated dynamically based on logins
    categories: [
      {
        id: 'c1',
        name: 'Information',
        channels: [
          { id: 'rules', name: 'rules', type: 'text' },
          { id: 'announcements', name: 'announcements', type: 'announcement' }
        ]
      },
      {
        id: 'c2',
        name: 'Text Channels',
        channels: [
          { id: 'general', name: 'general', type: 'text' },
          { id: 'chat', name: 'chat', type: 'text' },
          { id: 'memes', name: 'memes', type: 'text' },
        ]
      },
      {
        id: 'c3',
        name: 'Voice Channels',
        channels: [
          { id: 'v1', name: 'General', type: 'voice' },
          { id: 'v2', name: 'Gaming', type: 'voice' }
        ]
      }
    ]
  }
];

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeServerId, setActiveServerId] = useState<string>(INITIAL_SERVER_DATA[0].id);
  const [activeChannelId, setActiveChannelId] = useState<string>('general');
  const [serverData, setServerData] = useState(INITIAL_SERVER_DATA);
  
  // Persistent Message Storage
  const [messages, setMessages] = useState<Record<string, Message[]>>(() => {
    const saved = localStorage.getItem('mendeleevo_messages');
    return saved ? JSON.parse(saved) : {
      'general': [
        { 
            id: 'm1', 
            content: 'Welcome to $mendeleevo$ server! Recording voice messages is now available.', 
            author: { id: 'system', username: 'System', status: 'online' } as User, 
            timestamp: new Date().toISOString(),
            type: 'text'
        }
      ]
    };
  });

  // Load User from Session
  useEffect(() => {
    const sessionUser = sessionStorage.getItem('mendeleevo_session');
    if (sessionUser) {
        setCurrentUser(JSON.parse(sessionUser));
    }
  }, []);

  // Save Messages on Update
  useEffect(() => {
    localStorage.setItem('mendeleevo_messages', JSON.stringify(messages));
  }, [messages]);

  const activeServer = serverData.find(s => s.id === activeServerId) || serverData[0];
  const allChannels = activeServer.categories.flatMap(c => c.channels);
  const activeChannel = allChannels.find(c => c.id === activeChannelId) || allChannels[0];

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    sessionStorage.setItem('mendeleevo_session', JSON.stringify(user));
    // Add user to server members visually
    const exists = activeServer.members.find(m => m.id === user.id);
    if (!exists) {
        // In a real app, this syncs from backend. 
        // Here we just ensure the current user shows up.
        setServerData(prev => prev.map(s => {
            if (s.id === activeServerId) {
                return { ...s, members: [...s.members, user] };
            }
            return s;
        }));
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    sessionStorage.removeItem('mendeleevo_session');
  };

  const handleSendMessage = (content: string, type: 'text' | 'audio') => {
    if (!currentUser) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      content, // For audio, this is the Base64 string
      type,
      author: currentUser,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => ({
      ...prev,
      [activeChannelId]: [...(prev[activeChannelId] || []), newMessage]
    }));
  };

  if (!currentUser) {
    return <AuthScreen onLogin={handleLogin} />;
  }

  // Combine current user with static/fake members for sidebar population
  const displayMembers = [
      currentUser, 
      ...activeServer.members.filter(m => m.id !== currentUser.id)
  ];

  return (
    <div className="flex h-screen overflow-hidden bg-[#313338]">
      <ServerSidebar 
        servers={serverData} 
        activeServerId={activeServerId} 
        onServerClick={setActiveServerId} 
      />
      
      <ChannelSidebar 
        server={activeServer} 
        activeChannelId={activeChannelId} 
        currentUser={currentUser} 
        onChannelClick={(id) => setActiveChannelId(id)}
        onLogout={handleLogout}
      />

      <ChatArea 
        channel={activeChannel} 
        messages={messages[activeChannelId] || []} 
        currentUser={currentUser}
        onSendMessage={handleSendMessage}
      />
      
      <UserSidebar members={displayMembers} />
    </div>
  );
};

export default App;