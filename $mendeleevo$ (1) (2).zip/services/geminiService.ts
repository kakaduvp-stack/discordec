// AI Service removed as per user request.
// This file is intentionally left empty to break dependencies on the Gemini SDK.
export const generateAIResponse = async () => { return ""; };
export class GeminiLiveService {}
